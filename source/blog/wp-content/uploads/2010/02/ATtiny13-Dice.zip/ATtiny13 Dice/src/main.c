/*  
 * Charlieplexed dice for ATtiny13
 * ian.truslove@gmail.com, Feb 9 2010
 */
 
#include <stdlib.h>
#include <util/delay.h>
#include <avr/eeprom.h>

//  LED Layout:
//  
//    (1)     (4)
//
//    (2) (7) (5)
//
//    (3)     (6)
//
//  LED1: PB0 --|>|-- PB1
//  LED2: PB1 --|>|-- PB0
//  LED3: PB1 --|>|-- PB2
//  LED4: PB2 --|>|-- PB1
//  LED5: PB2 --|>|-- PB0
//  LED6: PB0 --|>|-- PB2
//  LED7: PB3 --|>|-- GND
//
//  +5V --- 10k pull-up resistor --- PB4 --- N/O Switch --- GND

const uint8_t LED_PORTB_DATA[] = { 
	0b0001, 
	0b0010, 
	0b0010, 
	0b0100, 
	0b0100,
	0b0001,
	0b1000 
};

const uint8_t LED_PORTB_MODE[] = {
	0b0011, 
	0b0011,
	0b0110,
	0b0110,
	0b0101,
	0b0101,
	0b1000
};



void powerOnTest(void);	
int getDiceRoll(void);
int rng(int, int);
void displayResult(int);

int main(void)
{
	powerOnTest ();
	
	uint8_t diceResult = 0;

	// Retrieve, increment and store a randseed to eeprom - so the number sequence isn't the same each time!
	uint8_t randSeed = eeprom_read_byte ((uint8_t*)1);
	++randSeed;
	eeprom_write_byte ((uint8_t*)1, randSeed);
	srand (randSeed);

	while (1 == 1)
	{
		int numCyclesInTransition = 0;
		
		// Wait for a button press to select a new random number
		// PINB pin 4 goes low only when the switch is pushed
		if ( (PINB & 0b0010000) == 0 )	
		{
			// Display some fast-moving "dice rolls"
			numCyclesInTransition = rng (4, 12);		// yes, the very most naive use of rand().  But really, the randomness here is just for show.  
			for (int i=0; i<numCyclesInTransition; ++i)
			{
				//diceResult = getDiceRoll ();
				diceResult = rng (1, 6);
				displayResult (diceResult);
				
				_delay_ms (100);
			}
		}
		
		// display the final dice roll result
		displayResult (diceResult);
   }

   return 1;
}

// Charlieplexing happens here...
void displayResult(int result)
{
	const int msecsDelay = 1;

	if ( result > 1 && result != 3 ) // i.e. result == 2 || result == 4 || result == 5 || result == 6
	{
		DDRB = LED_PORTB_MODE[0];
		PORTB = LED_PORTB_DATA[0];
		_delay_ms (msecsDelay);
		
		DDRB = LED_PORTB_MODE[5];
		PORTB = LED_PORTB_DATA[5];
		_delay_ms (msecsDelay);
	}
	
	if ( result == 6 )
	{
		DDRB = LED_PORTB_MODE[1];
		PORTB = LED_PORTB_DATA[1];
		_delay_ms (msecsDelay);
		
		DDRB = LED_PORTB_MODE[4];
		PORTB = LED_PORTB_DATA[4];
		_delay_ms (msecsDelay);
	}
	
	if ( result > 2 ) // i.e. result == 3 || result == 4 || result == 5 || result == 6 )
	{
		DDRB = LED_PORTB_MODE[2];
		PORTB = LED_PORTB_DATA[2];
		_delay_ms (msecsDelay);
		
		DDRB = LED_PORTB_MODE[3];
		PORTB = LED_PORTB_DATA[3];
		_delay_ms (msecsDelay);
	}

	if ( (result & 0b1) != 0 ) // i.e. result is odd, i.e. result == 1 || result == 3 || result == 5
	{
		DDRB = LED_PORTB_MODE[6];
		PORTB = LED_PORTB_DATA[6];
		_delay_ms (msecsDelay);
	}

}

// Do some flashy lighty bits on startup.  No good reason other than fluff.
void powerOnTest(void)
{
	const int msecsDelayPost = 100;
	
	for (int i=0; i<=6; ++i)
	{
		DDRB = LED_PORTB_MODE[i];
		PORTB = LED_PORTB_DATA[i];
		_delay_ms (msecsDelayPost);
	}
}

// Return a random number in the range min <= n <= max
int rng(int min, int max)
{
	return (min + (rand() / (RAND_MAX/(max+1))));	// not using _quite_ the most naive application of rand()
}
